import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-content',
  templateUrl: './right-content.component.html',
  styleUrls: ['./right-content.component.css']
})
export class RightContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
