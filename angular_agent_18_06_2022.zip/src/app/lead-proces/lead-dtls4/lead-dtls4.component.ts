import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AgentDataServiceService } from 'src/app/services/agent-data-service.service';
import { AgentCommonServiceService } from 'src/app/services/agent-common-service.service';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-lead-dtls4',
  templateUrl: './lead-dtls4.component.html',
  styleUrls: ['./lead-dtls4.component.css']
})
export class LeadDtls4Component implements OnInit {
  @Output() showAddressDivOut = new EventEmitter<string>()

  contactDetailsId: string = '';
  countryCode: string = '';
  emailAddress: string = '';
  faxCountryCode: string = '';
  faxNumber: string = '';
  faxStdCode: string = '';
  mobileNumber: string = '';
  officeCountryCode: string = '';
  officeStdCode: string = '';
  officeTelNumber: string = '';
  processId: string = '';
  residenceCountryCode: string = '';
  residenceStdCode: string = '';
  residenceTelNumber: string = '';

  contactDtlsForm: any;

  regObj: any;
  applicantID: any;
  agentCommnentArrData: any;


  display: string = "none";
  commentID: number = 0;
  commentData: string = '';


  isDisplayAddComment: boolean = true;
  isDisplayAddApprove: boolean = true;
  isDislplayCommentTextArea: boolean = true;
  isDislplayCommentUpdateBtn: boolean = false;
  isDisplayEditDeleteCommentSection: boolean = false;
  isDisplayProceedNext: boolean = false;

  isApproved: boolean = true;
  approveMsg: string = '';

  constructor(private agentDataServiceService: AgentDataServiceService, private agentCommonServiceService: AgentCommonServiceService, private fb: FormBuilder, private activeRt: ActivatedRoute) { }

  ngOnInit(): void {


    this.regObj = this.agentCommonServiceService.getUserFromLocalStorage();
    this.applicantID = Number(this.activeRt.snapshot.paramMap.get('applicantID'));

    this.contactDtlsForm = this.fb.group({
      comments: []
    })



    let Obj = {
      user_id: this.regObj.user_id,
      process_id: 11,
      applicant_id: this.applicantID
    }

    /*
    applicant_id: 29
    contact_details_id: 4
    country_code: "+91"
    email_address: "sankar@s.com"
    fax_country_code: "91"
    fax_number: 9991212122
    fax_std_code: "022"
    mobile_number: 9112121212
    office_country_code: "91"
    office_std_code: "022"
    office_tel_number: 9121212122
    process_id: 11
    process_name: "Contact details"
    residence_country_code: "91"
    residence_std_code: "022"
    residence_tel_number: 9122122121
    */

    this.agentDataServiceService.fetchContactDtls(Obj).subscribe((value) => {


      this.contactDetailsId = value?.data?.[0].contact_details_id
      this.countryCode = value?.data?.[0].country_code
      this.emailAddress = value?.data?.[0].email_address
      this.faxCountryCode = value?.data?.[0].fax_country_code
      this.faxNumber = value?.data?.[0].fax_number
      this.faxStdCode = value?.data?.[0].fax_std_code
      this.mobileNumber = value?.data?.[0].mobile_number
      this.officeCountryCode = value?.data?.[0].office_country_code
      this.officeStdCode = value?.data?.[0].office_std_code
      this.officeTelNumber = value?.data?.[0].office_tel_number
      this.processId = value?.data?.[0].process_id
      this.contactDetailsId = value?.data?.[0].process_name
      this.residenceCountryCode = value?.data?.[0].residence_country_code
      this.residenceStdCode = value?.data?.[0].residence_std_code
      this.residenceTelNumber = value?.data?.[0].residence_tel_number
    })




    let ObjC = {
      lead_id: this.regObj?.customerUserID,
      agent_id: this.regObj?.user_id,
      process_id: 11
    }

    this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
      console.log("This is agents comment", data);
      if (data?.data[0]?.comment_id) {
        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = true;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = true;
        this.isDisplayProceedNext = true;

        if(data?.data[0]?.agent_status==="approved")
        {

        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = false;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = false;
        this.isDisplayProceedNext = false;

        this.showAddressDivOut.emit();
        this.showAddressDivOut.emit();

        this.isApproved=true;
        this.approveMsg = 'This section is approved';
        }

        this.agentCommnentArrData = data;
        this.commentData = data?.data[0].comment;
        this.commentID = data?.data[0]?.comment_id;
      }
    })
  }


  get comments() { return this.contactDtlsForm.get('comments').value }

  addComment() {

    this.isDisplayAddComment = false;
    this.isDisplayAddApprove = true;
    this.isDislplayCommentTextArea = false;
    this.isDislplayCommentUpdateBtn = false;
    this.isDisplayEditDeleteCommentSection = true;
    this.isDisplayProceedNext = true;


    let Obj = {
      process_id: 11,
      applicant_id: this.applicantID,
      parent_comment_id: 0,
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      comment: this.contactDtlsForm.get('comments').value,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {
      console.log(value);
      let ObjC = {
        lead_id: this.regObj?.customerUserID,
        agent_id: this.regObj?.user_id,
        "process_id": 11
      }

      this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
        console.log("This is agents comment", data);
        this.agentCommnentArrData = data;
        this.commentData = data?.data[0].comment;
        this.commentID = data?.data[0]?.comment_id;
      })
    }, (err) => {
      console.log(err);
    })

  }

  updateComment() {


    this.isDisplayAddComment = false;
    this.isDisplayAddApprove = true;
    this.isDislplayCommentTextArea = false;
    this.isDislplayCommentUpdateBtn = false;
    this.isDisplayEditDeleteCommentSection = true;
    this.isDisplayProceedNext = true;

    let Obj = {
      process_id: 11,
      applicant_id: this.applicantID,
      parent_comment_id: 0,
      agent_id: this.agentCommonServiceService.getUserFromLocalStorage()?.user_id,
      comment: this.contactDtlsForm.get('comments').value,
      lead_id: this.regObj?.customerUserID,
      comment_id: this.commentID
    }

    this.agentDataServiceService.postAgentsComment(Obj).subscribe((value) => {

      //console.log(value)
    }, (err) => {
      console.log(err);
    })



    let ObjC = {
      lead_id: this.regObj?.customerUserID,
      agent_id: this.regObj?.user_id,
      process_id: 11
    }

    this.agentDataServiceService.fetchAgentCommentSummary(ObjC).subscribe((data) => {
      console.log("This is agents comment", data);
      this.agentCommnentArrData = data;
      this.commentData = data?.data[0].comment;
      this.commentID = data?.data[0]?.comment_id;
    })



  }

  openModal() {
    this.display = "block";
  }

  onCloseHandled() {
    this.display = "none";
  }


  editComment() {
    this.isDisplayAddComment = false;
    this.isDisplayAddApprove = true;
    this.isDislplayCommentTextArea = true;
    this.isDislplayCommentUpdateBtn = true;
    this.isDisplayEditDeleteCommentSection = false;
    this.isDisplayProceedNext = false;
  }

  checkDeleteComment() {
    this.isDisplayAddComment = true;
    this.isDisplayAddApprove = true;
    this.isDislplayCommentTextArea = true;
    this.isDislplayCommentUpdateBtn = false;
    this.isDisplayEditDeleteCommentSection = false;
    this.isDisplayProceedNext = false;

    this.openModal();
  }

  deleteComment() {
    window.location.reload();

    if (this.commentID > 0) {
      let Obj = {
        comment_id: this.commentID
      }
      this.agentDataServiceService.deleteComment(Obj).subscribe((value) => {
        console.log('Comment is deleted');
      });
    } else {

    }

  }

  proceedNext() {
    this.showAddressDivOut.emit();
  }

  approveLead() {




    let Obj = {
      applicant_id: this.applicantID,
      process_id: 11,
      lead_id: this.regObj?.customerUserID
    }

    this.agentDataServiceService.approveLead(Obj).subscribe((value) => {
      console.log('THis lead is approved');
      this.isApproved = true;
      this.approveMsg = 'This section is approved';

      // location.href='#personalDtls';


      if (value?.msg) {
        this.isDisplayAddComment = false;
        this.isDisplayAddApprove = false;
        this.isDislplayCommentTextArea = false;
        this.isDislplayCommentUpdateBtn = false;
        this.isDisplayEditDeleteCommentSection = false;
        this.isDisplayProceedNext = false;

        this.showAddressDivOut.emit();
      }

    })

  }

}
