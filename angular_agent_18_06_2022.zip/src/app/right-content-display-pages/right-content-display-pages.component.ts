import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-content-display-pages',
  templateUrl: './right-content-display-pages.component.html',
  styleUrls: ['./right-content-display-pages.component.css']
})
export class RightContentDisplayPagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
