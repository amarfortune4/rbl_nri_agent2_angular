import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-content-pages',
  templateUrl: './right-content-pages.component.html',
  styleUrls: ['./right-content-pages.component.css']
})
export class RightContentPagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
